import java.util.HashMap;
import java.util.LinkedList;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;


public class SAP {
    private final Digraph g;  // constructor takes a digraph (not necessarily a DAG)
    private final int V;
	public SAP(Digraph G) {
	   this.g = new Digraph(G); // immutable
	   this.V = this.g.V();
	   }
	
	private HashMap<Integer, Integer> allAncestor(int v) {
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		LinkedList<Integer> que = new LinkedList<Integer>();
		que.add(v);
		map.put(v, 0);
		int len = 1;
		while (!que.isEmpty()) {
			int size = que.size();
			for (int i = 0; i < size; i++) {
				int cur = que.poll();
				for (int adjacent : g.adj(cur)) {
					if (!map.containsKey(adjacent) && adjacent != v) {
						map.put(adjacent, len);
						que.add(adjacent);
						}
					}
				}
			len++;
			}
		return map;
		}
	private int[] shortlen(int v, int w) {
		HashMap<Integer, Integer> ancestorOfV = allAncestor(v);
		HashMap<Integer, Integer> ancestorOfW = allAncestor(w);
		int[] result = new int[2];
		int len = Integer.MAX_VALUE;
		int common = -1;
		for (int ancestor : ancestorOfV.keySet()) {
			if (ancestorOfW.containsKey(ancestor)) {
				int curLen = ancestorOfV.get(ancestor) + ancestorOfW.get(ancestor);
				if (curLen < len) {
					len = curLen;
					common = ancestor;
					}
				}
			}
		if (len == Integer.MAX_VALUE || common == -1) {
			result[0] = -1;
			result[1] = -1;
			}
		else {
			result[0] = len;
			result[1] = common;
			}
		return result;
		}
	private int[] shortlen(Iterable<Integer> v, Iterable<Integer> w) { 
		
		
		int minLen = Integer.MAX_VALUE;
		int ancestor = -1;
		for (int vNode: v) {
			for (int wNode: w) {
				int[] tmp = shortlen(vNode, wNode);
				if (tmp[0] != -1 && tmp[0] < minLen) {
					minLen = tmp[0];
					ancestor = tmp[1];
				}
			}
		}
		if (minLen == Integer.MAX_VALUE) {
			return new int[]{-1, -1};
		}
		return new int[]{minLen, ancestor};
		}
		
	/*private int[] shortLen(int v, int w) {
		if (v < 0 || v >= V || w < 0 || w >= V)
			throw new java.lang.IndexOutOfBoundsException();
		
		BreadthFirstDirectedPaths bfsV = new BreadthFirstDirectedPaths(g, v);
		BreadthFirstDirectedPaths bfsW = new BreadthFirstDirectedPaths(g, w);
		int minLength = Integer.MAX_VALUE;
		int common = -1;
		for (int i = 0; i < V; i++){
			if (bfsV.hasPathTo(i) && bfsW.hasPathTo(i)) {
				int curLen = bfsV.distTo(i) + bfsW.distTo(i);
				if (curLen < minLength) {
					minLength = curLen;
					common = i;
				}
			}
		}
		if (minLength == Integer.MAX_VALUE) {
			minLength = -1;
		}
		return new int[]{minLength, common};
	}
	private int[] shortLen(Iterable<Integer> v, Iterable<Integer> w) {
		
		BreadthFirstDirectedPaths bfsV = new BreadthFirstDirectedPaths(g, v);
		BreadthFirstDirectedPaths bfsW = new BreadthFirstDirectedPaths(g, w);
		
		int minLength = Integer.MAX_VALUE;
		int common = -1;
		for (int i = 0; i < V; i++){
			if (bfsV.hasPathTo(i) && bfsW.hasPathTo(i)) {
				int curLen = bfsV.distTo(i) + bfsW.distTo(i);
				if (curLen < minLength) {
					minLength = curLen;
					common = i;
				}
			}
		}
		if (minLength == Integer.MAX_VALUE) {
			minLength = -1;
		}
		return new int[]{minLength, common};
		
		
	}*/
	public int length(int v, int w) { // length of shortest ancestral path between v and w; -1 if no such path
		int[] shortest = shortlen(v, w);
		return shortest[0];
		}
	
	public int ancestor(int v, int w) { // a common ancestor of v and w that participates in a shortest ancestral path;
		int[] shortest = shortlen(v, w);
		return shortest[1];
		}
	
	public int length(Iterable<Integer> v, Iterable<Integer> w) { // length of shortest ancestral path between any vertex in v and any vertex in w
		if (v == null || w == null)
			throw new java.lang.NullPointerException();
		/*int[] shortest = shortLen(v, w);
		return shortest[0];*/
		int[] shortest = shortlen(v, w);
		return shortest[0];
		}
	
	public int ancestor(Iterable<Integer> v, Iterable<Integer> w) { // a common ancestor that participates in shortest ancestral path;
		if (v == null || w == null)
			throw new java.lang.NullPointerException();
		int[] shortest = shortlen(v, w);
		return shortest[1];
		}
	
	public static void main(String[] args) { // do unit testing of this class
		In in = new In(args[0]);
		Digraph G = new Digraph(in);
		System.out.print(G.E());
		SAP sap = new SAP(G);
		while (!StdIn.isEmpty()) {
			int v = StdIn.readInt();
			int w = StdIn.readInt();
	        int length   = sap.length(v, w);
	        int ancestor = sap.ancestor(v, w);
	        StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
	    }
   }
}